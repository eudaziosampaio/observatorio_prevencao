
# API Looker Studio + IA (FastAPI)

Esta API recebe uma tabela (em JSON), processa com GPT-4 e retorna um resumo inteligente. Ideal para integrar com Google Sheets e Looker Studio.

## Deploy rápido

- [Render](https://render.com): Crie um novo serviço web → conecte o repositório → defina o comando `uvicorn main:app --host 0.0.0.0 --port 10000`
- Defina a variável de ambiente `OPENAI_API_KEY` com sua chave.

## Endpoint

`POST /summary` com o corpo JSON:
```json
{
  "tabela": [
    {"Data": "2024-01", "Casos": 123},
    {"Data": "2024-02", "Casos": 140}
  ]
}
```
