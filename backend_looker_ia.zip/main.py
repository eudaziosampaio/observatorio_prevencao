
from fastapi import FastAPI
from pydantic import BaseModel
import openai
import pandas as pd
from fastapi.middleware.cors import CORSMiddleware
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class DataRequest(BaseModel):
    tabela: list

@app.post("/summary")
def gerar_resumo(req: DataRequest):
    df = pd.DataFrame(req.tabela)
    texto_csv = df.to_csv(index=False)
    prompt = f"Analise os seguintes dados e gere um resumo inteligente com tendências, padrões e alertas:

{texto_csv}"

    resposta = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5
    )
    return {"resumo": resposta.choices[0].message.content.strip()}
